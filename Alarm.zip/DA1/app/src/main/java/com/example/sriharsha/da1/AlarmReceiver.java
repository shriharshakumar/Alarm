package com.example.sriharsha.da1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by Sri Harsha on 1/30/2016.
 */
public class AlarmReceiver extends BroadcastReceiver {

    static Ringtone r;

    @Override
    public void onReceive(Context k1, Intent k2) {
        // TODO Auto-generated method stub
            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            r = RingtoneManager.getRingtone(k1, notification);
            //playing sound alarm
            r.play();
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (r.isPlaying())
                    r.stop();
            }
        }, 20000);

    }







}
